"use client";
import { motion } from "framer-motion";
import { Timeline } from "@/components/ui/timeline";
import { NavbarDemo } from "../components/Navbar";
import Footer from "../components/Footer";

export default function About() {
  const timelineData = [
    {
      title: "2014",
      content: (
        <div>
          <p className="text-neutral-200 text-xs md:text-sm font-normal mb-8">
            Started my journey in cinematography as a camera assistant on independent films.
            Learned the fundamentals of lighting, composition, and visual storytelling while
            working with seasoned professionals in the industry.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div
              className="h-20 md:h-44 lg:h-60 w-full rounded-lg bg-gradient-to-br from-neutral-200 dark:from-neutral-900 dark:to-neutral-800 to-neutral-100"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=500&h=300&fit=crop')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }}
            />
            <div
              className="h-20 md:h-44 lg:h-60 w-full rounded-lg bg-gradient-to-br from-neutral-200 dark:from-neutral-900 dark:to-neutral-800 to-neutral-100"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1518105779142-d975f22f1b0a?w=500&h=300&fit=crop')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }}
            />
          </div>
        </div>
      ),
    },
    {
      title: "2017",
      content: (
        <div>
          <p className="text-neutral-200 text-xs md:text-sm font-normal mb-8">
            Transitioned to Director of Photography role on my first feature film.
            This breakthrough project showcased my ability to create compelling visual narratives
            and established my reputation in the independent film circuit.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div
              className="h-20 md:h-44 lg:h-60 w-full rounded-lg bg-gradient-to-br from-neutral-200 dark:from-neutral-900 dark:to-neutral-800 to-neutral-100"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=500&h=300&fit=crop')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }}
            />
            <div
              className="h-20 md:h-44 lg:h-60 w-full rounded-lg bg-gradient-to-br from-neutral-200 dark:from-neutral-900 dark:to-neutral-800 to-neutral-100"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1489599904472-84d414e4e2b5?w=500&h=300&fit=crop')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }}
            />
          </div>
        </div>
      ),
    },
    {
      title: "2019",
      content: (
        <div>
          <p className="text-neutral-200 text-xs md:text-sm font-normal mb-8">
            Expanded into commercial cinematography, working with major brands and advertising agencies.
            Developed expertise in high-end commercial production, combining artistic vision with
            brand storytelling requirements.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div
              className="h-20 md:h-44 lg:h-60 w-full rounded-lg bg-gradient-to-br from-neutral-200 dark:from-neutral-900 dark:to-neutral-800 to-neutral-100"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=500&h=300&fit=crop')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }}
            />
            <div
              className="h-20 md:h-44 lg:h-60 w-full rounded-lg bg-gradient-to-br from-neutral-200 dark:from-neutral-900 dark:to-neutral-800 to-neutral-100"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=500&h=300&fit=crop')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }}
            />
          </div>
        </div>
      ),
    },
    {
      title: "2022",
      content: (
        <div>
          <p className="text-neutral-200 text-xs md:text-sm font-normal mb-4">
            Received recognition at international film festivals for outstanding cinematography.
            My work on documentary films brought attention to important social issues while
            maintaining the highest visual standards.
          </p>
          <p className="text-neutral-200 text-xs md:text-sm font-normal mb-8">
            Established my own production company, focusing on creating impactful visual content
            for both commercial and artistic projects.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div
              className="h-20 md:h-44 lg:h-60 w-full rounded-lg bg-gradient-to-br from-neutral-200 dark:from-neutral-900 dark:to-neutral-800 to-neutral-100"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&h=300&fit=crop')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }}
            />
            <div
              className="h-20 md:h-44 lg:h-60 w-full rounded-lg bg-gradient-to-br from-neutral-200 dark:from-neutral-900 dark:to-neutral-800 to-neutral-100"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1485846234645-a62644f84728?w=500&h=300&fit=crop')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }}
            />
          </div>
        </div>
      ),
    },
    {
      title: "Present",
      content: (
        <div>
          <p className="text-neutral-200 text-xs md:text-sm font-normal mb-8">
            Currently working on cutting-edge projects that push the boundaries of visual storytelling.
            Collaborating with innovative directors and brands to create content that resonates with
            global audiences and sets new standards in cinematography.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div
              className="h-20 md:h-44 lg:h-60 w-full rounded-lg bg-gradient-to-br from-neutral-200 dark:from-neutral-900 dark:to-neutral-800 to-neutral-100"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=500&h=300&fit=crop')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }}
            />
            <div
              className="h-20 md:h-44 lg:h-60 w-full rounded-lg bg-gradient-to-br from-neutral-200 dark:from-neutral-900 dark:to-neutral-800 to-neutral-100"
              style={{
                backgroundImage: "url('https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=500&h=300&fit=crop')",
                backgroundSize: "cover",
                backgroundPosition: "center"
              }}
            />
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="bg-black min-h-screen">
      <NavbarDemo />

      {/* Hero Section with Photo and Description */}
      <section className="pt-24 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Photo Section */}
            <motion.div
              className="relative"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <div className="relative w-full h-[600px] rounded-2xl overflow-hidden">
                <div
                  className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900"
                  style={{
                    backgroundImage: "url('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=1000&fit=crop&crop=face')",
                    backgroundSize: "cover",
                    backgroundPosition: "center"
                  }}
                />
                {/* Overlay for better text contrast */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
              </div>
            </motion.div>

            {/* Description Section */}
            <motion.div
              className="space-y-8"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            >
              <div>
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
                  About Me
                </h1>
                <div className="w-20 h-1 bg-white mb-8"></div>
              </div>

              <div className="space-y-6 text-gray-300 text-lg leading-relaxed">
                <p>
                  I'm a passionate cinematographer with over a decade of experience in visual storytelling.
                  My journey began with a simple fascination for how light and shadow could convey emotion,
                  and it has evolved into a career dedicated to crafting compelling visual narratives.
                </p>

                <p>
                  Throughout my career, I've had the privilege of working on diverse projects ranging from
                  intimate independent films to large-scale commercial productions. Each project has taught
                  me something new about the art of cinematography and the power of visual communication.
                </p>

                <p>
                  My approach combines technical expertise with artistic vision, always seeking to serve
                  the story while pushing creative boundaries. I believe that every frame should contribute
                  to the narrative, creating an immersive experience that resonates with audiences long
                  after the credits roll.
                </p>
              </div>

              {/* Stats */}
              <motion.div
                className="grid grid-cols-3 gap-8 pt-8"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
              >
                <div className="text-center">
                  <div className="text-3xl font-bold text-white mb-2">10+</div>
                  <div className="text-gray-400 text-sm">Years Experience</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-white mb-2">150+</div>
                  <div className="text-gray-400 text-sm">Projects Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-white mb-2">25+</div>
                  <div className="text-gray-400 text-sm">Awards Won</div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <Timeline data={timelineData} />

      <Footer />
    </div>
  );
}