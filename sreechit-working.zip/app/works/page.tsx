"use client";
import { motion } from "framer-motion";
import { NavbarDemo } from "../components/Navbar";
import Footer from "../components/Footer";
import { useState } from "react";
import { Carousel, Card } from "@/components/ui/apple-cards-carousel";

interface VideoItem {
  id: number;
  title: string;
  subtitle?: string;
  thumbnail: string;
  type: 'video' | 'trailer' | 'watch';
  category: string;
}

export default function Works() {
  const [hoveredItem, setHoveredItem] = useState<number | null>(null);

  // Feature Films data for Apple Cards Carousel
  const featureFilmsData = [
    {
      src: "https://images.unsplash.com/photo-1489599904472-84d414e4e2b5?w=800&h=1200&fit=crop",
      title: "Dhal Dhak",
      category: "Hindi Feature Film",
      content: (
        <div className="bg-[#F5F5F7] dark:bg-neutral-800 p-8 md:p-14 rounded-3xl mb-4">
          <p className="text-neutral-600 dark:text-neutral-400 text-base md:text-2xl font-sans max-w-3xl mx-auto">
            <span className="font-bold text-neutral-700 dark:text-neutral-200">
              A compelling drama that explores the depths of human emotion through masterful cinematography.
            </span>{" "}
            This feature film showcases innovative lighting techniques and visual storytelling that brings 
            the narrative to life. Shot over 45 days across multiple locations, the film demonstrates 
            the power of visual narrative in Hindi cinema.
          </p>
          <div className="flex gap-4 mt-8">
            <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
              Watch Trailer
            </button>
            <button className="border border-gray-300 text-gray-700 dark:text-gray-300 px-6 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
              Behind the Scenes
            </button>
          </div>
        </div>
      ),
    },
    {
      src: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=800&h=1200&fit=crop",
      title: "TVF-Sandeep Bhaiya",
      category: "Web Series",
      content: (
        <div className="bg-[#F5F5F7] dark:bg-neutral-800 p-8 md:p-14 rounded-3xl mb-4">
          <p className="text-neutral-600 dark:text-neutral-400 text-base md:text-2xl font-sans max-w-3xl mx-auto">
            <span className="font-bold text-neutral-700 dark:text-neutral-200">
              A breakthrough web series that redefined digital storytelling in India.
            </span>{" "}
            Working with The Viral Fever, this project pushed the boundaries of web content cinematography. 
            The series features dynamic camera work and innovative lighting setups that create an immersive 
            viewing experience for digital audiences.
          </p>
          <div className="flex gap-4 mt-8">
            <button className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors">
              Watch Now
            </button>
            <button className="border border-gray-300 text-gray-700 dark:text-gray-300 px-6 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
              Production Notes
            </button>
          </div>
        </div>
      ),
    },
    {
      src: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&h=1200&fit=crop",
      title: "Medical Dreams",
      category: "Documentary",
      content: (
        <div className="bg-[#F5F5F7] dark:bg-neutral-800 p-8 md:p-14 rounded-3xl mb-4">
          <p className="text-neutral-600 dark:text-neutral-400 text-base md:text-2xl font-sans max-w-3xl mx-auto">
            <span className="font-bold text-neutral-700 dark:text-neutral-200">
              An intimate documentary exploring the journey of medical professionals.
            </span>{" "}
            This documentary required a delicate balance of observational cinematography and artistic vision. 
            Shot in real medical environments, the film captures authentic moments while maintaining 
            the highest visual standards and ethical considerations.
          </p>
          <div className="flex gap-4 mt-8">
            <button className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-colors">
              Watch Documentary
            </button>
            <button className="border border-gray-300 text-gray-700 dark:text-gray-300 px-6 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
              Director's Commentary
            </button>
          </div>
        </div>
      ),
    },
    {
      src: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=1200&fit=crop",
      title: "Shadows & Light",
      category: "Art Film",
      content: (
        <div className="bg-[#F5F5F7] dark:bg-neutral-800 p-8 md:p-14 rounded-3xl mb-4">
          <p className="text-neutral-600 dark:text-neutral-400 text-base md:text-2xl font-sans max-w-3xl mx-auto">
            <span className="font-bold text-neutral-700 dark:text-neutral-200">
              An experimental art film that pushes the boundaries of visual storytelling.
            </span>{" "}
            This project explores the interplay between light and shadow as narrative elements. 
            Using minimal dialogue and maximum visual impact, the film demonstrates how cinematography 
            can carry the entire emotional weight of a story.
          </p>
          <div className="flex gap-4 mt-8">
            <button className="bg-purple-600 text-white px-6 py-2 rounded-lg hover:bg-purple-700 transition-colors">
              View Film
            </button>
            <button className="border border-gray-300 text-gray-700 dark:text-gray-300 px-6 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
              Artist Statement
            </button>
          </div>
        </div>
      ),
    },
  ];

  const featureFilms: VideoItem[] = [
    {
      id: 1,
      title: "Dhal Dhak (Hindi)",
      thumbnail: "https://images.unsplash.com/photo-1489599904472-84d414e4e2b5?w=400&h=600&fit=crop",
      type: "trailer",
      category: "Feature Film"
    },
    {
      id: 2,
      title: "TVF-Sandeep Bhaiya",
      thumbnail: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=400&h=600&fit=crop",
      type: "watch",
      category: "Web Series"
    },
    {
      id: 3,
      title: "Medical Dreams",
      thumbnail: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=400&h=600&fit=crop",
      type: "watch",
      category: "Documentary"
    }
  ];

  const shortOriginals: VideoItem[] = [
    {
      id: 4,
      title: "Shotons",
      thumbnail: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&h=400&fit=crop",
      type: "video",
      category: "Short Film"
    },
    {
      id: 5,
      title: "Webseries",
      thumbnail: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=300&h=400&fit=crop",
      type: "video",
      category: "Web Series"
    }
  ];

  const webSeries: VideoItem[] = [
    {
      id: 6,
      title: "Digital Films",
      thumbnail: "https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=300&h=400&fit=crop",
      type: "video",
      category: "Digital"
    },
    {
      id: 7,
      title: "Film Promo Digital Films",
      thumbnail: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=300&h=400&fit=crop",
      type: "video",
      category: "Promo"
    }
  ];

  const digitalCommercials = [
    "The Man Company",
    "Brahmastra logo film",
    "Godrej",
    "Toofaan",
    "Test",
    "Toofaan",
    "Test"
  ];

  const filmPromos = [
    "Shershaah",
    "Sardar Udham Singh",
    "Toofaan",
    "83 - The Film"
  ];

  const documentaries: VideoItem[] = [
    {
      id: 8,
      title: "The Man",
      thumbnail: "https://images.unsplash.com/photo-1518105779142-d975f22f1b0a?w=300&h=400&fit=crop",
      type: "video",
      category: "Documentary"
    },
    {
      id: 9,
      title: "Commenia",
      thumbnail: "https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=300&h=400&fit=crop",
      type: "video",
      category: "Documentary"
    }
  ];

  const digitalCorporate: VideoItem[] = [
    {
      id: 10,
      title: "Music Films",
      thumbnail: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=300&h=400&fit=crop",
      type: "video",
      category: "Music Video"
    },
    {
      id: 11,
      title: "Showreel",
      thumbnail: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=300&h=400&fit=crop",
      type: "video",
      category: "Showreel"
    }
  ];

  const upcomingProjects: VideoItem[] = [
    {
      id: 12,
      title: "Aspirants",
      thumbnail: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=300&h=400&fit=crop",
      type: "video",
      category: "Upcoming"
    },
    {
      id: 13,
      title: "Sardar",
      thumbnail: "https://images.unsplash.com/photo-1489599904472-84d414e4e2b5?w=300&h=400&fit=crop",
      type: "video",
      category: "Upcoming"
    }
  ];

  const VideoCard = ({ item, size = "large" }: { item: VideoItem; size?: "large" | "medium" }) => (
    <motion.div
      className={`relative group cursor-pointer ${
        size === "large" ? "aspect-[2/3]" : "aspect-[3/4]"
      }`}
      onHoverStart={() => setHoveredItem(item.id)}
      onHoverEnd={() => setHoveredItem(null)}
      whileHover={{ scale: 1.05 }}
      transition={{ duration: 0.3 }}
    >
      <div
        className="w-full h-full rounded-lg bg-cover bg-center relative overflow-hidden"
        style={{ backgroundImage: `url(${item.thumbnail})` }}
      >
        {/* Overlay */}
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-all duration-300" />
        
        {/* Play Button */}
        <div className="absolute inset-0 flex items-center justify-center">
          <motion.div
            className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
          >
            <svg className="w-8 h-8 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </motion.div>
        </div>

        {/* Title Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
          <h3 className="text-white font-semibold text-sm md:text-base">{item.title}</h3>
          {item.subtitle && (
            <p className="text-gray-300 text-xs mt-1">{item.subtitle}</p>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="absolute top-4 right-4 flex gap-2">
        {item.type === "trailer" && (
          <span className="bg-blue-600 text-white text-xs px-2 py-1 rounded">Trailer</span>
        )}
        {item.type === "watch" && (
          <span className="bg-green-600 text-white text-xs px-2 py-1 rounded">Watch</span>
        )}
      </div>
    </motion.div>
  );

  const TextItem = ({ title, isActive = false }: { title: string; isActive?: boolean }) => (
    <motion.div
      className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors ${
        isActive ? "bg-gray-800" : "hover:bg-gray-800/50"
      }`}
      whileHover={{ x: 5 }}
    >
      <span className="text-gray-300">{title}</span>
      <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
      </svg>
    </motion.div>
  );

  return (
    <div className="bg-black min-h-screen">
      <NavbarDemo />
      
      <div className="pt-24 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <motion.div
            className="mb-12"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4">
              My Work
            </h1>
            <p className="text-gray-400 text-lg max-w-2xl">
              A journey through films, series, commercials, and creative storytelling
            </p>
          </motion.div>

          {/* Feature Films - Apple Cards Carousel */}
          <motion.section
            className="mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-8">Feature Films</h2>
            <Carousel items={featureFilmsData.map((card, index) => (
              <Card key={card.src} card={card} index={index} />
            ))} />
          </motion.section>

          {/* Two Column Layout with Dynamic Alignment */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Left Column */}
            <div className="flex flex-col">
              {/* Short Originals */}
              <motion.section
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="mb-16"
              >
                <h2 className="text-2xl font-bold text-white mb-6">Short Originals</h2>
                <div className="grid grid-cols-2 gap-4">
                  {shortOriginals.map((item) => (
                    <VideoCard key={item.id} item={item} size="medium" />
                  ))}
                </div>
              </motion.section>

              {/* Digital Commercials */}
              <motion.section
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="mb-16 flex-1 flex flex-col"
              >
                <h2 className="text-2xl font-bold text-white mb-6">Digital Commercials</h2>
                <div className="space-y-2 flex-1">
                  {digitalCommercials.map((title, index) => (
                    <TextItem key={index} title={title} />
                  ))}
                  {/* Dynamic spacer to match the height of Film Promo section */}
                  {Array.from({ length: Math.max(0, filmPromos.length - digitalCommercials.length) }).map((_, index) => (
                    <div key={`spacer-${index}`} className="h-[52px]" /> // Height of one TextItem
                  ))}
                </div>
              </motion.section>

              {/* Documentaries */}
              <motion.section
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                <h2 className="text-2xl font-bold text-white mb-6">Documentaries</h2>
                <div className="grid grid-cols-2 gap-4">
                  {documentaries.map((item) => (
                    <VideoCard key={item.id} item={item} size="medium" />
                  ))}
                </div>
              </motion.section>
            </div>

            {/* Right Column */}
            <div className="flex flex-col">
              {/* Webseries */}
              <motion.section
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="mb-16"
              >
                <h2 className="text-2xl font-bold text-white mb-6">Webseries</h2>
                <div className="grid grid-cols-2 gap-4">
                  {webSeries.map((item) => (
                    <VideoCard key={item.id} item={item} size="medium" />
                  ))}
                </div>
              </motion.section>

              {/* Film Promo Digital Films */}
              <motion.section
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="mb-16 flex-1 flex flex-col"
              >
                <h2 className="text-2xl font-bold text-white mb-6">Film Promo Digital Films</h2>
                <div className="space-y-2 flex-1">
                  {filmPromos.map((title, index) => (
                    <TextItem key={index} title={title} />
                  ))}
                  {/* Dynamic spacer to match the height of Digital Commercials section */}
                  {Array.from({ length: Math.max(0, digitalCommercials.length - filmPromos.length) }).map((_, index) => (
                    <div key={`spacer-${index}`} className="h-[52px]" /> // Height of one TextItem
                  ))}
                </div>
              </motion.section>

              {/* Digital Corporate Films */}
              <motion.section
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                <h2 className="text-2xl font-bold text-white mb-6">Digital Corporate Films</h2>
                <div className="grid grid-cols-2 gap-4">
                  {digitalCorporate.map((item) => (
                    <VideoCard key={item.id} item={item} size="medium" />
                  ))}
                </div>
              </motion.section>
            </div>
          </div>

          {/* Upcoming Projects */}
          <motion.section
            className="mt-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
          >
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-8">
              Upcoming Projects (2025)
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {upcomingProjects.map((item) => (
                <VideoCard key={item.id} item={item} size="medium" />
              ))}
            </div>
            
            {/* Watch Showreel Button */}
            <div className="text-center">
              <motion.button
                className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors duration-200"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Watch My Showreel
              </motion.button>
            </div>
          </motion.section>
        </div>
      </div>

      <Footer />
    </div>
  );
}