"use client";

import { useState } from "react";
import LoadingScreen from "./components/LoadingScreen";
import { NavbarDemo } from "./components/Navbar";
import { ContainerScroll } from "@/components/ui/container-scroll-animation";
import FeaturedSection from "./components/FeaturedSection";
import Testimonials from "./components/Testimonials";
import Footer from "./components/Footer";

export default function Home() {
  const [showLoading, setShowLoading] = useState(true);

  const handleLoadingComplete = () => {
    setShowLoading(false);
  };

  if (showLoading) {
    return <LoadingScreen onComplete={handleLoadingComplete} />;
  }

  return (
    <div className="bg-black">
      <NavbarDemo />
      <div className="pt-16"> {/* Add padding to account for fixed navbar */}
        {/* Container Scroll Hero with Modal */}
        <ContainerScroll
          titleComponent={
            <div>
              <h1 className="text-5xl md:text-8xl bg-clip-text text-transparent bg-gradient-to-b from-white to-neutral-600 font-bold mb-4">
                Sreechith Vijayan Damodar
              </h1>
              <p className="text-neutral-400 text-lg md:text-xl max-w-2xl mx-auto px-4">
                Crafting cinematic experiences through the art of light, movement, and shadow.
                Every frame tells a story.
              </p>
            </div>
          }
        >
          <iframe
            src="https://www.youtube.com/embed/rIPwDmJVjjo?autoplay=1&mute=1&controls=0&showinfo=0&rel=0&loop=1&playlist=rIPwDmJVjjo&modestbranding=1&iv_load_policy=3&fs=0&disablekb=1&enablejsapi=1"
            title="Cinematography Showreel"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            className="w-full h-full"
            style={{ border: 'none' }}
            allowFullScreen
          />
        </ContainerScroll>

        <FeaturedSection />
        <Testimonials />
      </div>
      <Footer />
    </div>
  );
}
